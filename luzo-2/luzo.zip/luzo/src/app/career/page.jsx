import React from 'react'
import Header from './Header'
import Form from './Form'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const index = () => {
  return (
    <div>
        <Navbar/>
         <Header/>
         <Form/>
         <Footer/>
    </div>
  )
}

export default index
