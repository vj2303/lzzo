"use client"
import React from 'react'
import ServiceContainer from "./Container"

const page = () => {
    return (
      <ServiceContainer />
    )
}

export default page