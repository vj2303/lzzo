import React from 'react'

const page = () => {
  return (
    <div>
         <h1>Hellooo neww</h1>
    </div>
  )
}

export default page
