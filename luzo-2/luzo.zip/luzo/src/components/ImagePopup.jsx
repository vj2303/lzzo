import React from 'react'

const ImagePopup = () => {
  return (
    <div>ImagePopup</div>
  )
}

export default ImagePopup